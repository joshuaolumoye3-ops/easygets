<?php $__env->startSection('title', 'Manage Prices'); ?>

<?php $__env->startSection('content'); ?>
    <main class="pt-[70px] w-full flex flex-col">
        <div class="p-[1.875rem_1.75rem] w-full flex-grow">
            <h1 class="text-xl font-bold text-white mb-6">Plans for <?php echo e($provider->name); ?></h1>

            <!-- Bulk Save Form -->
            <form action="<?php echo e(route('admin.products.save', $provider->id)); ?>" method="POST"
                class="mb-6 bg-[#191c24] p-4 rounded-xl text-white">
                <?php echo csrf_field(); ?>
                <div class="flex flex-col md:flex-row items-center gap-4">
                    <input type="number" step="0.01" id="price_input" name="price_input"
                        <?php if($provider->percentage == 1): ?>
                            placeholder="Enter percentage (e.g., 70 for 70%)"
                        <?php else: ?>
                            placeholder="Enter client price"
                        <?php endif; ?>
                        class="px-3 py-2 rounded text-black w-full md:w-1/3" required>

                    <input type="hidden" id="client_price" name="client_price">

                    <button type="submit" class="bg-green px-4 py-2 rounded-lg">Save All Plans</button>
                </div>

                <script>
                    document.querySelector('form').addEventListener('submit', function(e) {
                        const priceInput = document.getElementById('price_input');
                        const clientPriceInput = document.getElementById('client_price');
                        const inputValue = parseFloat(priceInput.value) || 0;

                        <?php if($provider->percentage == 1): ?>
                            const multiplier = 1 + (inputValue / 100);
                            clientPriceInput.value = multiplier.toFixed(2);
                            console.log('Percentage mode:', inputValue + '% → Multiplier:', multiplier);
                        <?php else: ?>
                            clientPriceInput.value = inputValue.toFixed(2);
                            console.log('Normal mode: Client price:', inputValue);
                        <?php endif; ?>
                    });
                </script>
            </form>

            <!-- Search Input -->
            <div class="mb-4">
                <input type="text" id="searchInput" placeholder="Search plans..."
                    class="w-full md:w-1/3 px-3 py-2 rounded text-black">
            </div>

            <!-- Products Table -->
            <div class="bg-[#191c24] rounded-xl shadow overflow-x-auto">
                <table class="w-full text-left text-white" id="productsTable">
                    <thead>
                        <tr class="border-b border-gray-700">
                            <th class="px-4 py-3">Category</th>
                            <th class="px-4 py-3">Plan</th>
                            <th class="px-4 py-3">API Price</th>
                            <th class="px-4 py-3">Client Price</th>
                            <th class="px-4 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b border-gray-700">
                                <td class="px-4 py-3"><?php echo e($product->category); ?></td>
                                <td class="px-4 py-3"><?php echo e($product->name); ?></td>
                                <td class="px-4 py-3">
                                    <span class="px-3 py-1 rounded-lg text-sm font-semibold"
                                        style="background-color:#03624C;">
                                        ₦<?php echo e(number_format($product->api_price, 2)); ?>

                                    </span>
                                </td>
                                <td class="px-4 py-3">
                                    <?php if($product->id): ?>
                                        <form action="<?php echo e(route('admin.products.update', ['id' => $product->id])); ?>"
                                            method="POST" class="flex items-center gap-2">
                                            <?php echo csrf_field(); ?>
                                            <input type="number" step="0.01" id="price_input_<?php echo e($product->id); ?>"
                                                name="price_input"
                                                value="<?php echo e($provider->percentage == 1 ? ($product->client_price - 1) * 100 : $product->client_price); ?>"
                                                class="px-2 py-1 rounded text-black w-32"
                                                <?php if($provider->percentage == 1): ?>
                                                    placeholder="Percentage"
                                                <?php else: ?>
                                                    placeholder="Client Price"
                                                <?php endif; ?>>

                                            <input type="hidden" id="client_price_<?php echo e($product->id); ?>" name="client_price">

                                            <button type="submit" class="bg-green px-3 py-1 rounded-lg">Save</button>
                                        </form>

                                        <script>
                                            document.getElementById('price_input_<?php echo e($product->id); ?>').closest('form').addEventListener('submit', function(e) {
                                                const priceInput = document.getElementById('price_input_<?php echo e($product->id); ?>');
                                                const clientPriceInput = document.getElementById('client_price_<?php echo e($product->id); ?>');
                                                const inputValue = parseFloat(priceInput.value) || 0;

                                                <?php if($provider->percentage == 1): ?>
                                                    // Percentage mode: convert to multiplier (e.g., 70 → 1.70)
                                                    const multiplier = 1 + (inputValue / 100);
                                                    clientPriceInput.value = multiplier.toFixed(2);
                                                <?php else: ?>
                                                    // Normal mode: use client price directly
                                                    clientPriceInput.value = inputValue.toFixed(2);
                                                <?php endif; ?>
                                            });
                                        </script>
                                    <?php else: ?>
                                        <span class="text-gray-400 text-sm">Not saved yet</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 flex items-center gap-3">
                                    <span class="text-sm text-gray-400">
                                        Last Updated: <?php echo e($product->updated_at->diffForHumans()); ?>

                                    </span>

                                    <!-- Delete Button -->
                                    <?php if($product->id): ?>
                                        <form action="<?php echo e(route('admin.products.delete', ['id' => $product->id])); ?>"
                                            method="POST"
                                            onsubmit="return confirm('Are you sure you want to delete this product?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit"
                                                class="bg-red-600 text-white px-3 py-1 rounded-lg">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    
    <script>
        document.getElementById('searchInput').addEventListener('keyup', function() {
            let filter = this.value.toLowerCase();
            let rows = document.querySelectorAll('#productsTable tbody tr');

            rows.forEach(row => {
                let text = row.innerText.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Desktop\hecks\hecksteckie\resources\views/admin/servicesprice.blade.php ENDPATH**/ ?>