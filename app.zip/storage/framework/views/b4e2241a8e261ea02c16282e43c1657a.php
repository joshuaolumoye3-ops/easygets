<!-- Social Form Modal -->
<div id="socialModal" class="fixed inset-0 z-50 bg-white w-full h-full overflow-y-auto hidden animate-slide-up">
    <div class="w-full max-w-md mx-auto p-4 sm:p-6 relative">
        <!-- Back Arrow Button -->
        <button onclick="closeSocialModal()" class="absolute left-4 top-4 focus:outline-none">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 text-gray-800 hover:text-green-700" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
        </button>

        <h2 class="text-2xl font-bold text-center mt-12 mb-6">Social Packages</h2>


        <form method="POST" action="<?php echo e(route('social.order')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label for="category" class="block text-gray-700 font-semibold mb-1">Select Category</label>
                <select id="category" name="category" class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category); ?>"><?php echo e($category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-4">
                <label for="package" class="block text-gray-700 font-semibold mb-1">Choose Package</label>
                <select id="package" name="service_id" class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
                   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service->id); ?>"
                                data-category="<?php echo e($category); ?>"
                                data-rate="<?php echo e($service->rate); ?>"
                                data-min="<?php echo e($service->min); ?>"
                                data-max="<?php echo e($service->max); ?>"
                                data-desc="<?php echo e($service->desc); ?>">
                                <?php echo e($service->name); ?> (₦<?php echo e(number_format($service->rate, 2)); ?>/1k)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-4">
                <label for="quantity" class="block text-gray-700 font-semibold mb-1">Quantity</label>
                <input type="number" id="quantity" name="quantity" placeholder="10" class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
            </div>

            <div class="mb-6">
                <label for="link" class="block text-gray-700 font-semibold mb-1">Post/Page Link</label>
                <input type="url" id="link" name="link" placeholder="https://example.com/link" class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500">
            </div>

            <!-- Dynamic Amount Box -->
            <div class="mb-4 text-center">
                <div class="bg-brand-green text-white font-bold rounded-xl py-4 mb-2">
                    <p class="text-lg">Amount</p>
                    <p id="amountDisplay" class="text-2xl">₦0</p>
                    <p id="perUnitDisplay" class="text-sm"></p>
                </div>
                <div class="bg-green-100 text-brand-green rounded-xl py-3 px-4 text-sm">
                    <p class="font-semibold">Description</p>
                    <p id="descDisplay">Select a package to see details.</p>
                </div>
            </div>

            <button type="submit" class="w-full bg-brand-green hover:bg-green-800 text-white font-semibold py-3 rounded-xl transition duration-300">
                Continue
            </button>
        </form>
    </div>
</div>

<style>
    .animate-slide-up {
        animation: slideUp .3s ease-out;
    }

    @keyframes slideUp {
        from {
            transform: translateY(30px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
</style>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const packageSelect = document.getElementById("package");
    const qtyInput = document.getElementById("quantity");
    const amountDisplay = document.getElementById("amountDisplay");
    const perUnitDisplay = document.getElementById("perUnitDisplay");
    const descDisplay = document.getElementById("descDisplay");

    function calculateAmount() {
        const selected = packageSelect.options[packageSelect.selectedIndex];
        const rate = parseFloat(selected.dataset.rate || 0);
        const min = parseInt(selected.dataset.min || 0);
        const max = parseInt(selected.dataset.max || 0);
        const desc = selected.dataset.desc || "No description available.";
        const qty = parseInt(qtyInput.value || 0);

        if (qty >= min && qty <= max) {
            const baseAmount = (rate * qty);
            const amount = baseAmount * <?php echo e($admin_rate ? $admin_rate : 0); ?>;
            const perce= <?php echo e($admin_rate-1); ?> *100;

            amountDisplay.textContent = "₦" + amount.toFixed(2);
            perUnitDisplay.textContent = `Min: ${min}, Max: ${max}`;
            descDisplay.textContent = desc + ` (Includes ${perce}% fee)`;
        } else {
            amountDisplay.textContent = "₦0";
            perUnitDisplay.textContent = `Enter between ${min} and ${max}`;
            descDisplay.textContent = desc;
        }
    }

    packageSelect.addEventListener("change", calculateAmount);
    qtyInput.addEventListener("input", calculateAmount);

    // Initialize
    calculateAmount();
});
</script>

<?php /**PATH C:\Users\USER\Desktop\hecks\hecksteckie\resources\views/partials/social-form.blade.php ENDPATH**/ ?>