

<?php $__env->startSection('title', 'Countries'); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-gray-50 min-h-screen font-[Inter]">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-8 max-w-lg bg-white shadow-sm">

        <!-- Header -->
        <div class="relative flex items-center justify-center mb-6">
            
            <a href="dashboard" class="absolute left-0 text-gray-500 hover:text-gray-700">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
                </svg>
            </a>
            
            <h1 class="text-2xl font-bold text-gray-800">Countries</h1>
        </div>

        <!-- Search Bar -->
        <div class="relative mb-8">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
            </span>
            
            <input 
                id="searchInput"
                type="text" 
                placeholder="Search <?php echo e(count($products)); ?> Countries..."
                class="w-full pl-10 pr-4 py-3 bg-gray-100 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none transition duration-200"
            >
        </div>

        <!-- Popular Products / Flags -->
        
        <div class="flex space-x-6 overflow-x-auto pb-4 mb-6 -mx-4 px-4">
            <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('products.countries', $product['id'])); ?>" 
                   class="flex-shrink-0 w-16 h-16 flex items-center justify-center rounded-full hover:opacity-80 transition-opacity">
                    
                    <img class="w-12 h-12 object-cover rounded-full" 
                         src="https://flagcdn.com/w80/<?php echo e(strtolower(substr($product['code'], 0, 2))); ?>.png" 
                         onerror="this.src='https://via.placeholder.com/48?text=<?php echo e(strtoupper(substr($product['code'],0,1))); ?>'" 
                         alt="<?php echo e($product['title']); ?>">
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- All Services List -->
        <div>
            
            <h2 class="text-xl font-bold text-gray-800 mb-4">All Services</h2>
            <div id="productList" class="space-y-4">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <a href="<?php echo e(route('products.countries', $product['id'])); ?>" 
                   class="flex items-center justify-between p-3 bg-white rounded-lg hover:bg-gray-50 transition-colors duration-200 product-item">
                    
                    
                    <div class="flex items-center">
                        <img class="w-10 h-10 rounded-full mr-4 object-cover" 
                             src="https://flagcdn.com/w80/<?php echo e(strtolower(substr($product['code'], 0, 2))); ?>.png" 
                             onerror="this.src='https://via.placeholder.com/40?text=<?php echo e(strtoupper(substr($product['code'],0,1))); ?>'" 
                             alt="<?php echo e($product['title']); ?>">
                        <span class="font-semibold text-gray-700 product-name"><?php echo e($product['title']); ?></span>
                    </div>

                    
                    
                    <div class="flex items-center space-x-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                        <span class="font-semibold text-green-500">
                            
                            <?php echo e(number_format(rand(5000, 35000))); ?>

                        </span>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<script>
    // The search script remains the same and will work with the updated structure.
    document.getElementById('searchInput').addEventListener('input', function () {
        let filter = this.value.toLowerCase();
        document.querySelectorAll('.product-item').forEach(function (item) {
            let name = item.querySelector('.product-name').textContent.toLowerCase();
            item.style.display = name.includes(filter) ? 'flex' : 'none'; // Changed to 'flex' to match the display property
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Desktop\hecks\hecksteckie\resources\views/users/country_otp.blade.php ENDPATH**/ ?>