<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('services.countries', $product['id'])); ?>" 
       class="flex items-center justify-between p-3 bg-white rounded-lg hover:bg-gray-50 transition-colors duration-200 product-item">
        <div class="flex items-center">
            <img class="w-10 h-10 rounded-full mr-4 object-cover" 
                 src="https://flagcdn.com/w80/<?php echo e(strtolower(substr($product['code'], 0, 2))); ?>.png" 
                 onerror="this.src='https://via.placeholder.com/40?text=<?php echo e(strtoupper(substr($product['code'],0,1))); ?>'" 
                 alt="<?php echo e($product['title']); ?>">
            <span class="font-semibold text-gray-700 product-name"><?php echo e($product['title']); ?></span>
        </div>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\USER\Desktop\hecks\hecksteckie\resources\views/partials/service_items.blade.php ENDPATH**/ ?>