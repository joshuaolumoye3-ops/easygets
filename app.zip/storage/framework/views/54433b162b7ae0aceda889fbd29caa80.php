 
<?php $__env->startSection('title', 'Manage Providers'); ?>

<?php $__env->startSection('content'); ?>
<main class="pt-[70px] w-full flex flex-col">
    <div class="p-[1.875rem_1.75rem] w-full flex-grow">
        <h1 class="text-xl font-bold text-white mb-6">Providers for <?php echo e($service->name); ?></h1>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div 
                    class="bg-[#191c24] text-white p-6 rounded-xl shadow hover:bg-[#23272f] cursor-pointer transition"
                    onclick="window.location='<?php echo e(route('admin.products', $provider->id)); ?>'">
                    <h2 class="text-xl font-bold mb-2"><?php echo e($provider->name); ?></h2>
                    <p class="text-muted">Click to manage <?php echo e($provider->name); ?> plans</p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Desktop\hecks\hecksteckie\resources\views/admin/serviceproviders.blade.php ENDPATH**/ ?>