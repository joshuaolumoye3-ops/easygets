<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <title><?php echo $__env->yieldContent('title', config('app.name', 'Laravel')); ?></title>

    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Alpine.js -->
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(asset('easygets-fav-black.png')); ?>" />

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif'],
                    },
                    colors: {
                        'brand-green': {
                            'DEFAULT': '#03624C',
                            'light': '#E6F5F1',
                            'medium': '#157A61',
                        },
                        'brand-gray': {
                            'light': '#F9FAFB',
                            'medium': '#E0E0E0',
                            'dark': '#4F4F4F'
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body {
            font-family: 'Inter', 'sans-serif';
        }
        [x-cloak] { display: none !important; }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="antialiased bg-white">

    
    <?php if(session('success') || session('error') || session('info') || $errors->any()): ?>
        <div id="flash-message" 
            class="fixed top-5 left-1/2 transform -translate-x-1/2 z-50 px-4 py-3 rounded-lg shadow-lg 
            <?php echo e(session('success') ? 'bg-green-500' : ''); ?>

            <?php echo e(session('error') ? 'bg-red-500' : ''); ?>

            <?php echo e(session('info') ? 'bg-blue-500' : ''); ?>

            <?php echo e($errors->any() ? 'bg-red-500' : ''); ?>

            text-white text-center min-w-[300px] max-w-[500px]">
            
            <?php if(session('success')): ?>
                <?php echo e(session('success')); ?>

            <?php elseif(session('error')): ?>
                <?php echo e(session('error')); ?>

            <?php elseif(session('info')): ?>
                <?php echo e(session('info')); ?>

            <?php elseif($errors->any()): ?>
                <?php echo e($errors->first()); ?>

            <?php endif; ?>
        </div>

        <script>
            setTimeout(() => {
                const flash = document.getElementById('flash-message');
                if(flash){
                    flash.classList.add('opacity-0', 'transition', 'duration-700');
                    setTimeout(() => flash.remove(), 700);
                }
            }, 5000); // Disappear after 5 seconds
        </script>
    <?php endif; ?>

    <div id="app" class="min-h-screen flex flex-col">
        <main class="flex-grow">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Users\USER\Desktop\hecks\hecksteckie\resources\views/layouts/app.blade.php ENDPATH**/ ?>