<!DOCTYPE html>
<html>
<body>
    <h2>Email Verification Code</h2>
    <p>Your OTP is <strong><?php echo e($otp); ?></strong>. It will expire in 5 minutes.</p>
</body>
</html>
<?php /**PATH C:\Users\USER\Desktop\hecks\hecksteckie\resources\views/emails/otp.blade.php ENDPATH**/ ?>