

<?php $__env->startSection('title', 'Sign in'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-col items-center justify-center min-h-screen px-4 py-12 bg-white" style="font-family: 'Inter', sans-serif;">
    <div class="w-full max-w-sm mx-auto">
        <div class="flex justify-center mb-6">
            <img src="https://i.ibb.co/6gT3YvJ/avatar.png" alt="User avatar" class="w-20 h-20 rounded-full" />
        </div>

        <div class="text-center">
            <h1 class="text-3xl font-bold text-gray-900">Sign in</h1>
            <p class="mt-2 text-sm text-gray-600">Login in to your account</p>
        </div>
 
        <form id="otpForm" method="POST" action="<?php echo e(route('login.submit')); ?>" class="mt-8 space-y-6">
            <?php echo csrf_field(); ?>
            <div class="flex justify-center">
                <div class="space-y-5 flex flex-col w-full max-w-xs">
                    <input
                        type="text"
                        name="login"
                        placeholder="Email or username"
                        class="w-full px-3 py-3 text-sm tracking-widest bg-white text-black rounded-full md:rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#03624C] transition-all"
                        required
                    />
                        <input
                        type="password"
                        name="password"
                        placeholder="Password"
                        class="w-full px-3 py-3 text-sm tracking-widest bg-white text-black rounded-full md:rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#03624C] transition-all"
                        required
                    />
                </div>
            </div>

            <div class="text-center">
                <a href="#" id="backLink" class="text-sm font-medium text-blue-600 transition-colors hover:text-gray-800">Forget password?</a>
            </div>

            <button
                type="submit"
                class="w-full py-3 text-base font-semibold bg-brand-green text-white transition-all duration-300 ease-in-out rounded-xl"
            >
                Login
            </button>
            <div class="text-center">
               Don't have an account? <a href="signup" id="backLink" class="text-sm font-medium text-blue-600 transition-colors hover:text-gray-800">Sign up</a>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Desktop\hecks\hecksteckie\resources\views/auth/login.blade.php ENDPATH**/ ?>