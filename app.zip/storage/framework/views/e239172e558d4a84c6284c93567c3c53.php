 
<?php $__env->startSection('title', 'Manage Services'); ?>

<?php $__env->startSection('content'); ?>
<main class="pt-[70px] w-full flex flex-col">
    <div class="p-[1.875rem_1.75rem] w-full flex-grow">
        
        <!-- Top Bar -->
        <div class="flex flex-col md:flex-row justify-between items-center bg-[#191c24] p-4 rounded-2xl shadow-md mb-6">
            <h1 class="text-lg sm:text-xl font-bold text-white">
                Manage Services
            </h1>
        </div>

        <!-- Services List -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div 
                    class="bg-[#191c24] text-white p-6 rounded-xl shadow hover:bg-[#23272f] cursor-pointer transition"
                    onclick="window.location='<?php echo e(route('admin.providers', $service->id)); ?>'">
                    <h2 class="text-xl font-bold mb-2"><?php echo e($service->name); ?></h2>
                    <p class="text-muted">Click to manage <?php echo e($service->name); ?> providers</p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Desktop\hecks\hecksteckie\resources\views/admin/servicelist.blade.php ENDPATH**/ ?>