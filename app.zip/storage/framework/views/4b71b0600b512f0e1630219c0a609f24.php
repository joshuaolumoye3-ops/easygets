<?php $__env->startSection('title', 'More Services'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto py-8 font-[Inter]">
    <div class="flex items-center space-x-2 mb-6">
        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-green-800" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
        </svg>
        <h1 class="text-lg font-semibold text-center flex-1">More Services</h1>
    </div>

    <div class="mb-6">
        <input type="text" placeholder="Search for a service..." class="w-full border rounded-full py-2 px-4 text-sm focus:outline-none focus:ring-2 focus:ring-green-800">
    </div>

    <h2 class="text-sm font-medium text-gray-500 mb-4">All Services</h2>

    <div class="space-y-4">
        <?php $__currentLoopData = [
            ['icon'=>'assets/wifi.svg','name'=>'Internet','btn'=>'Buy Data', 'href'=>'data'],
            ['icon'=>'assets/phone.svg','name'=>'Airtime','btn'=>'Recharge', 'href'=>'airtime'],
            ['icon'=>'assets/electricity.svg','name'=>'Electricity','btn'=>'Pay Bill', 'href'=>'electricity'],
            ['icon'=>'assets/tv.svg','name'=>'TV/Cable','btn'=>'Subscribe', 'href'=>'cabletv'],
            ['icon'=>'🏦','name'=>'Banking','btn'=>'Deposit', 'href'=>'deposit'],
            ['icon'=>'assets/e-sim.svg','name'=>'eSIM','btn'=>'Activate', 'href'=>'esim'],
            ['icon'=>'assets/sim-icon.svg','name'=>'eSIM Renewal','btn'=>'Renew', 'href'=>'esim'],
            ['icon'=>'assets/ball.svg','name'=>'Bettinng','btn'=>'Betting', 'href'=>'betting'],
            ['icon'=>'📝','name'=>'JAMB e-PIN','btn'=>'Buy', 'href'=>'jambepin'],
            // ['icon'=>'📖','name'=>'WAEC e-PIN','btn'=>'Buy', 'href'=>'waecepin'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex items-center justify-between border-b pb-3">
            <div class="flex items-center space-x-4">
                <div class="text-green-800 text-xl"><img src="<?php echo $service['icon']; ?>" alt="<?php echo e($service['name']); ?>" class="w-8"></div>
                <p class="text-base font-medium"><?php echo e($service['name']); ?></p>
            </div>
            <a href="<?php echo e(url($service['href'])); ?>" class="bg-green-800 text-white text-xs px-4 py-2 rounded-full"><?php echo e($service['btn']); ?></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Desktop\hecks\hecksteckie\resources\views/users/moreService.blade.php ENDPATH**/ ?>