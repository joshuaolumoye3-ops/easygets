<?php

namespace App\Http\Controllers;

use App\Helpers\PinHelper;
use App\Models\EsimCountry;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\Wallet;
use Illuminate\Support\Str;

class CountryController extends Controller
{
    // Provider constants
    const PROVIDER_5SIM = '5sim';
    const PROVIDER_SMSBUS = 'smsbus';

    public function showServices(Request $request)
{
    $token = env('SMSBUS_TOKEN');
    $cacheKey = 'smsbus_services';
    $backupCacheKey = 'smsbus_services_backup';
    
    $products = Cache::get($cacheKey);
    
    if (!$products || $products->isEmpty()) {
        try {
            $response = Http::timeout(30)
                ->connectTimeout(15)
                ->retry(3, function ($exception, $request) {
                    Log::info('Retrying SMS-Bus API call', ['attempt' => $request->attempt ?? 1]);
                    return 2000;
                })
                ->withOptions(['verify' => false])
                ->get("https://sms-bus.com/api/control/list/projects", [
                    'token' => $token
                ]);

            if ($response->successful()) {
                $data = $response->json('data');
                if (is_array($data) && !empty($data)) {
                    $products = collect($data)->values();
                    Cache::put($cacheKey, $products, now()->addMinutes(30));
                    Cache::put($backupCacheKey, $products, now()->addDays(7));
                    Log::info('SMS-Bus API call successful', ['count' => $products->count()]);
                } else {
                    throw new \Exception('Invalid API response data');
                }
            } else {
                throw new \Exception('API returned status: ' . $response->status());
            }
            
        } catch (\Exception $e) {
            Log::error('SMS-Bus API Error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            $products = Cache::get($backupCacheKey);
            
            if (!$products || $products->isEmpty()) {
                $products = $this->getMockServices();
                Log::warning('Using mock data due to API failure');
            } else {
                Log::info('Using backup cache data', ['count' => $products->count()]);
            }
        }
    }

    $iconMap = $this->getServiceIconMap();
    $products = $products->map(function ($product) use ($iconMap) {
        $code = strtolower($product['code']);
        $iconUrl = $iconMap[$code] ?? null;
        
        if (!$iconUrl) {
            $initials = strtoupper(substr($product['title'], 0, 2));
            $colors = ['10b981', '3b82f6', '8b5cf6', 'f59e0b', 'ef4444', '06b6d4'];
            $color = $colors[crc32($code) % count($colors)];
            $iconUrl = "https://ui-avatars.com/api/?name={$initials}&background={$color}&color=ffffff&size=96&format=svg";
        }
        
        $product['icon_url'] = $iconUrl;
        $product['large_icon_url'] = $iconUrl;
        return $product;
    });

    $popularCodes = ['wa', 'fb', 'tg', 'google', 'ig'];
    $popular = $products->filter(fn($p) => in_array(strtolower($p['code']), $popularCodes));

    $search = $request->input('search');
    if ($search) {
        $products = $products->filter(function($p) use ($search) {
            return str_contains(strtolower($p['title']), strtolower($search)) ||
                   str_contains(strtolower($p['code']), strtolower($search));
        });
    }

    $others = $search ? $products : $products->reject(fn($p) => in_array(strtolower($p['code']), $popularCodes));

    $perPage = 30;
    $page = $request->input('page', 1);
    $offset = ($page - 1) * $perPage;
    
    $paginated = $others->slice($offset, $perPage)->values();
    $hasMorePages = $others->count() > ($page * $perPage);

    // Handle AJAX requests for infinite scroll
    if ($request->ajax() || $request->input('ajax') == '1') {
        $html = '';
        
        // Build HTML directly instead of using partial view
        foreach ($paginated as $product) {
            $iconDisplay = '';
            if (str_contains($product['icon_url'], '.svg')) {
                $iconDisplay = '<div class="w-6 h-6 service-icon" style="background-image: url(\'' . $product['icon_url'] . '\'); background-size: contain; background-repeat: no-repeat; background-position: center;"></div>';
            } else {
                $iconDisplay = '<img src="' . $product['icon_url'] . '" alt="' . htmlspecialchars($product['title']) . '" class="w-6 h-6 object-contain" loading="lazy" onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';">
                    <div class="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-xs font-bold" style="display: none;">' . strtoupper(substr($product['title'], 0, 2)) . '</div>';
            }
            
            $html .= '<button onclick="showProviderModal(\'' . $product['id'] . '\', \'' . addslashes($product['title']) . '\', \'' . strtolower($product['code']) . '\')" class="w-full block group">
                <div class="flex items-center space-x-4 p-4 border border-gray-100 rounded-xl hover:border-green-200 hover:bg-green-50/50 transition-all duration-200 group-hover:shadow-sm">
                    <div class="w-12 h-12 rounded-full bg-gray-50 flex items-center justify-center overflow-hidden flex-shrink-0 group-hover:bg-white transition-colors duration-200">
                        ' . $iconDisplay . '
                    </div>
                    <div class="flex-1 min-w-0">
                        <h3 class="text-sm font-semibold text-gray-800 group-hover:text-green-700 transition-colors">
                            ' . htmlspecialchars($product['title']) . '
                        </h3>
                        <p class="text-xs text-gray-500 mt-1">
                            ' . strtoupper($product['code']) . '
                        </p>
                    </div>
                    <div class="flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-400 group-hover:text-green-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                        </svg>
                    </div>
                </div>
            </button>';
        }
        
        Log::info('AJAX request processed', [
            'page' => $page,
            'items_returned' => $paginated->count(),
            'has_more' => $hasMorePages,
            'html_length' => strlen($html)
        ]);
        
        return response()->json([
            'html' => $html,
            'next_page' => $hasMorePages ? $page + 1 : null,
            'has_more' => $hasMorePages,
            'current_page' => $page,
            'total' => $others->count()
        ]);
    }

    return view('users.services', [
        'popular'   => $popular,
        'products'  => $paginated,
        'nextPage'  => $hasMorePages ? 2 : null
    ]);
}

private function getServiceIconMap()
{
    return [
        'facebook' => 'https://cdn-icons-png.flaticon.com/512/733/733547.png',
        'instagram' => 'https://cdn-icons-png.flaticon.com/512/2111/2111463.png',
        'twitter' => 'https://cdn-icons-png.flaticon.com/512/733/733579.png',
        'tiktok' => 'https://cdn-icons-png.flaticon.com/512/3046/3046121.png',
        'whatsapp' => 'https://cdn-icons-png.flaticon.com/512/733/733585.png',
        'telegram' => 'https://cdn-icons-png.flaticon.com/512/2111/2111646.png',
        'gmail' => 'https://cdn-icons-png.flaticon.com/512/732/732200.png',
        'youtube' => 'https://cdn-icons-png.flaticon.com/512/1384/1384060.png',
        'snapchat' => 'https://cdn-icons-png.flaticon.com/512/2111/2111800.png',
        'amazon' => 'https://cdn-icons-png.flaticon.com/512/5968/5968253.png',
        'microsoft' => 'https://cdn-icons-png.flaticon.com/512/732/732221.png',
        'yahoo' => 'https://cdn-icons-png.flaticon.com/512/732/732205.png',
        'netflix' => 'https://cdn-icons-png.flaticon.com/512/5977/5977590.png',
        'wechat' => 'https://cdn-icons-png.flaticon.com/512/888/888879.png',
        'paypal' => 'https://cdn-icons-png.flaticon.com/512/174/174861.png',
        'linkedin' => 'https://cdn-icons-png.flaticon.com/512/174/174857.png',
        'default' => 'https://cdn-icons-png.flaticon.com/512/1828/1828884.png'
    ];
}


    private function fetchCountriesFromAPI()
{
    try {
        $token = env('SMSBUS_TOKEN');
        
        if (!$token) {
            Log::error('SMSBUS_TOKEN not configured');
            throw new \Exception('SMSBUS_TOKEN not configured in .env file');
        }

        Log::info('Fetching countries from SMS-Bus API...');

        $response = Http::timeout(30)->get("https://sms-bus.com/api/control/list/countries", [
            'token' => $token,
        ]);

        Log::info('API Response Status: ' . $response->status());

        if ($response->failed()) {
            Log::error('Failed to fetch countries from SMS-Bus API', [
                'status' => $response->status(),
                'body' => $response->body()
            ]);
            throw new \Exception('API request failed with status: ' . $response->status());
        }

        $responseData = $response->json();
        
        Log::info('API Response Data Structure', [
            'has_data_key' => isset($responseData['data']),
            'data_is_array' => isset($responseData['data']) && is_array($responseData['data']),
            'data_count' => isset($responseData['data']) ? count($responseData['data']) : 0,
            'response_keys' => array_keys($responseData)
        ]);

        if (!isset($responseData['data']) || empty($responseData['data'])) {
            Log::error('No data returned from SMS-Bus countries API', [
                'response' => $responseData
            ]);
            throw new \Exception('No country data in API response');
        }

        $countries = collect($responseData['data'])
            ->map(function ($country) {
                $countryCode = strtoupper($country['country_code'] ?? $country['iso2'] ?? '');
                
                return [
                    'country_name' => $country['country_name'] ?? $country['name'] ?? 'Unknown',
                    'country_code' => $countryCode,
                    'flag_url'     => $country['flag_url'] ?? "https://flagcdn.com/w320/" . strtolower($countryCode) . ".png",
                    'base_price'   => 0,
                    'is_active'    => true,
                    'created_at'   => now(),
                    'updated_at'   => now(),
                ];
            })
            ->filter(function($country) {
                return !empty($country['country_code']) && 
                       $country['country_name'] !== 'Unknown' &&
                       strlen($country['country_code']) == 2;
            })
            ->unique('country_code')
            ->values()
            ->toArray();

        if (empty($countries)) {
            Log::warning('No valid countries found after filtering API response');
            throw new \Exception('No valid countries after filtering');
        }

        Log::info('Filtered countries count: ' . count($countries));

        // Insert in chunks to avoid memory issues
        $inserted = 0;
        foreach (array_chunk($countries, 50) as $chunk) {
            foreach ($chunk as $country) {
                EsimCountry::updateOrCreate(
                    ['country_code' => $country['country_code']],
                    $country
                );
                $inserted++;
            }
        }

        Log::info('Successfully fetched and stored eSIM countries', [
            'total_countries' => count($countries),
            'inserted' => $inserted
        ]);

        return [
            'success' => true,
            'count' => $inserted
        ];
        
    } catch (\Exception $e) {
        Log::error('Error fetching eSIM countries from API', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * ✅ Get Exchange Rate or Conversion Price
 */
private function getExchangeRate(): float
    {
        try {
            // Find the OTP provider
            $otpProvider = \App\Models\Provider::where('api_identifier', 'Admin-otp')
                ->orWhere('api_identifier', 'otp')
                ->first();

            if ($otpProvider) {
                // Find the OTP product linked to this provider
                $otpProduct = \App\Models\Product::where('provider_id', $otpProvider->id)
                    ->where('product_code', 'otp-verification')
                    ->where('is_active', true)
                    ->first();

                if ($otpProduct && $otpProduct->client_price > 0) {
                    Log::info('Exchange rate from OTP product', [
                        'rate' => $otpProduct->client_price
                    ]);
                    return (float) $otpProduct->client_price;
                }
            }

            Log::warning('OTP product not found, using default exchange rate');
        } catch (\Exception $e) {
            Log::error('Error fetching exchange rate', [
                'error' => $e->getMessage()
            ]);
        }

        // ✅ Default fallback rate (₦1500 per $1)
        return 1500.0;
    }


    // ==================== 5SIM.NET METHODS ====================
    
    // Step 1: Get countries for a service (5sim)
    public function showCountries5sim($serviceCode)
    {
        // Don't cache for now during debugging
        // $cacheKey = "5sim_countries_{$serviceCode}";
        
        try {
            Log::info('5sim showCountries called', ['serviceCode' => $serviceCode]);
            
            // Build the URL
            $url = "https://5sim.net/v1/guest/products/any/any/{$serviceCode}";
            Log::info('5sim API URL', ['url' => $url]);
            
            // Make the request
            $response = Http::timeout(30)
                ->withOptions(['verify' => false])
                ->get($url, [
                    'single' => 0,
                    'sort' => 'top'
                ]);

            Log::info('5sim API Response', [
                'status' => $response->status(),
                'successful' => $response->successful(),
                'body_preview' => substr($response->body(), 0, 500)
            ]);

            if (!$response->successful()) {
                Log::error('5sim countries API failed', [
                    'status' => $response->status(),
                    'body' => $response->body()
                ]);
                
                return view('users.countries-5sim', [
                    'countries' => collect([]),
                    'serviceCode' => $serviceCode
                ])->withErrors('Unable to fetch countries from 5sim. Please try again.');
            }

            $data = $response->json();
            Log::info('5sim parsed data', ['count' => count($data)]);
            
            $countries = [];
            
            foreach ($data as $countryName => $details) {
                $countries[] = [
                    'name' => $countryName,
                    'code' => $this->getCountryCode($countryName),
                    'qty' => $details['Qty'] ?? 0,
                    'price' => $details['Price'] ?? 0,
                    'category' => $details['Category'] ?? 'activation'
                ];
            }
            
            Log::info('5sim countries processed', ['total' => count($countries)]);
            
            // Sort by quantity (descending)
            usort($countries, function($a, $b) {
                return $b['qty'] - $a['qty'];
            });
            
            $countries = collect($countries);
            
            $search = request()->get('search', '');
            
            if ($search) {
                $countries = $countries->filter(function($country) use ($search) {
                    return str_contains(strtolower($country['name']), strtolower($search));
                });
            }

            if (request()->ajax()) {
                return response()->json([
                    'data' => $countries->values(),
                    'success' => true
                ]);
            }

            return view('users.countries-5sim', [
                'countries' => $countries,
                'serviceCode' => $serviceCode
            ]);
            
        } catch (\Exception $e) {
            Log::error('5sim countries exception', [
                'service' => $serviceCode,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return view('users.countries-5sim', [
                'countries' => collect([]),
                'serviceCode' => $serviceCode
            ])->withErrors('An error occurred: ' . $e->getMessage());
        }
    }

    // Step 2: Get operators for a country and service (5sim)
    public function showOperators5sim($serviceCode, $country)
    {
        try {
            Log::info('5sim showOperators called', [
                'serviceCode' => $serviceCode,
                'country' => $country
            ]);
            
            $url = "https://5sim.net/v1/guest/prices";
            
            $response = Http::timeout(30)
                ->withOptions(['verify' => false])
                ->get($url, [
                    'product' => $serviceCode,
                    'country' => $country
                ]);

            Log::info('5sim operators API response', [
                'status' => $response->status(),
                'url' => $url,
                'params' => ['product' => $serviceCode, 'country' => $country],
                'body_preview' => substr($response->body(), 0, 500)
            ]);

            if (!$response->successful()) {
                Log::error('5sim operators API failed', [
                    'status' => $response->status(),
                    'body' => $response->body()
                ]);
                
                return view('users.operators-5sim', [
                    'operators' => collect([]),
                    'serviceCode' => $serviceCode,
                    'country' => $country
                ])->withErrors('Unable to fetch operators. Please try again.');
            }

            $data = $response->json();
            $operators = [];
            
            Log::info('5sim operators data structure', [
                'has_country' => isset($data[$country]),
                'has_service' => isset($data[$country][$serviceCode]),
                'keys' => array_keys($data)
            ]);
            
            // Navigate the nested structure
            if (isset($data[$country][$serviceCode])) {
                foreach ($data[$country][$serviceCode] as $operatorName => $details) {
                    $operators[] = [
                        'name' => $operatorName,
                        'display_name' => $this->formatOperatorName($operatorName),
                        'cost' => $details['cost'] ?? 0,
                        'count' => $details['count'] ?? 0,
                        'rate' => $details['rate'] ?? 0,
                        'rate24' => $details['rate24'] ?? null,
                        'rate72' => $details['rate72'] ?? null,
                    ];
                }
                
                Log::info('5sim operators found', ['count' => count($operators)]);
            } else {
                Log::warning('5sim no operators in response structure', [
                    'country' => $country,
                    'service' => $serviceCode
                ]);
            }
            
            // Sort by count (descending)
            usort($operators, function($a, $b) {
                return $b['count'] - $a['count'];
            });
            
            return view('users.operators-5sim', [
                'operators' => collect($operators),
                'serviceCode' => $serviceCode,
                'country' => $country
            ]);
            
        } catch (\Exception $e) {
            Log::error('5sim operators exception', [
                'service' => $serviceCode,
                'country' => $country,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            
            return view('users.operators-5sim', [
                'operators' => collect([]),
                'serviceCode' => $serviceCode,
                'country' => $country
            ])->withErrors('An error occurred: ' . $e->getMessage());
        }
    }

    private function formatOperatorName($operatorName)
    {
        // Replace underscores, hyphens, and dots with spaces
        $formatted = str_replace(['_', '-', '.'], ' ', $operatorName);

        // Convert to lowercase and capitalize words
        $formatted = ucwords(strtolower($formatted));

        // Common replacements for better display
        $formatted = str_ireplace([
            'Mts', 'Beeline', 'Tele2', 'Megafon', 'Air', 'Sms'
        ], [
            'MTS', 'Beeline', 'Tele2', 'MegaFon', 'Air', 'SMS'
        ], $formatted);

        return trim($formatted);
    }


    // Prepare purchase for 5sim
    public function preparePurchase5sim(Request $request)
    {
        $request->validate([
            'service' => 'required|string',
            'country' => 'required|string',
            'operator' => 'required|string',
        ]);

        $serviceCode = $request->service;
        $country = $request->country;
        $operator = $request->operator;

        // ✅ Get service details
        $serviceDetails = $this->getServiceDetails($serviceCode, true);
        
        // ✅ Get country details
        $countryDetails = $this->getCountryDetails($country, true);

        // Fetch current price
        $cacheKey = "5sim_price_{$serviceCode}_{$country}_{$operator}";
        $priceData = Cache::remember($cacheKey, 180, function () use ($serviceCode, $country, $operator) {
            try {
                $response = Http::timeout(20)
                    ->withOptions(['verify' => false])
                    ->get("https://5sim.net/v1/guest/prices", [
                        'product' => $serviceCode,
                        'country' => $country
                    ]);

                if ($response->successful()) {
                    $data = $response->json();
                    
                    if (isset($data[$country][$serviceCode][$operator])) {
                        return $data[$country][$serviceCode][$operator];
                    }
                }
                
                return null;
            } catch (\Exception $e) {
                Log::error('5sim price fetch error', ['error' => $e->getMessage()]);
                return null;
            }
        });

        if (!$priceData || !isset($priceData['cost'])) {
            return back()->withErrors('Unable to fetch pricing. Please try again.');
        }

        $usdToNgn = $this->getExchangeRate();

        $purchase = [
            'provider' => self::PROVIDER_5SIM,
            'country' => $country,
            'service' => $serviceCode,
            'operator' => $operator,
            'service_name' => $serviceDetails['name'],
            'country_name' => $countryDetails['name'],
            'country_code' => $countryDetails['code'],
            'operator_name' => $this->formatOperatorName($operator),
            'cost' => round($priceData['cost'] * $usdToNgn, 2),
            'original_cost_usd' => $priceData['cost'],
            'exchange_rate' => $usdToNgn,
            'total_count' => $priceData['count'] ?? 0,
            'rate' => $priceData['rate'] ?? 0,
            'timestamp' => time(),
            'session_token' => bin2hex(random_bytes(16)),
        ];

        if ($purchase['cost'] <= 0) {
            return back()->withErrors('Invalid pricing. Please contact support.');
        }

        session(['purchase' => encrypt($purchase)]);

        Log::info('5sim purchase session created', [
            'user_id' => auth()->id(),
            'service' => $serviceCode,
            'service_name' => $serviceDetails['name'],
            'country' => $country,
            'country_name' => $countryDetails['name'],
            'operator' => $operator,
            'exchange_rate' => $usdToNgn
        ]);

        return redirect()->route('confirm.payment');
    }

    private function getCountryCode($countryName)
{
    // Normalize the name (remove spaces, hyphens, and lowercase)
    $normalized = strtolower(str_replace([' ', '-', '_'], '', $countryName));

    // Common country name → ISO2 code mappings
    $map = [
        'russia' => 'ru', 'ukraine' => 'ua', 'kazakhstan' => 'kz',
        'china' => 'cn', 'philippines' => 'ph', 'myanmar' => 'mm',
        'indonesia' => 'id', 'malaysia' => 'my', 'kenya' => 'ke',
        'tanzania' => 'tz', 'vietnam' => 'vn', 'kyrgyzstan' => 'kg',
        'usa' => 'us', 'israel' => 'il', 'hongkong' => 'hk',
        'poland' => 'pl', 'england' => 'gb', 'nigeria' => 'ng',
        'india' => 'in', 'egypt' => 'eg', 'france' => 'fr',
        'germany' => 'de', 'italy' => 'it', 'spain' => 'es',
        'ghana' => 'gh', 'canada' => 'ca', 'turkey' => 'tr',
        'southafrica' => 'za', 'brazil' => 'br', 'mexico' => 'mx',
        'japan' => 'jp', 'australia' => 'au', 'singapore' => 'sg',
        'saudiarabia' => 'sa', 'pakistan' => 'pk', 'bangladesh' => 'bd'
    ];

    // Return the matching code or 'un' (unknown) if not found
    return $map[$normalized] ?? 'un';
}

    private function getCountryCodeFrom5simCountry($countryName)
    {
        // Map 5sim country names to ISO codes
        $countryMap = [
            'russia' => 'ru',
            'ukraine' => 'ua',
            'kazakhstan' => 'kz',
            'china' => 'cn',
            'philippines' => 'ph',
            'myanmar' => 'mm',
            'indonesia' => 'id',
            'malaysia' => 'my',
            'kenya' => 'ke',
            'tanzania' => 'tz',
            'vietnam' => 'vn',
            'kyrgyzstan' => 'kg',
            'usa' => 'us',
            'israel' => 'il',
            'hongkong' => 'hk',
            'poland' => 'pl',
            'england' => 'gb',
            'madagascar' => 'mg',
            'congo' => 'cd',
            'nigeria' => 'ng',
            'macau' => 'mo',
            'egypt' => 'eg',
            'india' => 'in',
            'ireland' => 'ie',
            'cambodia' => 'kh',
            'laos' => 'la',
            'haiti' => 'ht',
            'ivorycoast' => 'ci',
            'gambia' => 'gm',
            'serbia' => 'rs',
            'yemen' => 'ye',
            'southafrica' => 'za',
            'romania' => 'ro',
            'colombia' => 'co',
            'estonia' => 'ee',
            'azerbaijan' => 'az',
            'canada' => 'ca',
            'morocco' => 'ma',
            'ghana' => 'gh',
            'argentina' => 'ar',
            'uzbekistan' => 'uz',
            'cameroon' => 'cm',
            'chad' => 'td',
            'germany' => 'de',
            'lithuania' => 'lt',
            'croatia' => 'hr',
            'sweden' => 'se',
            'iraq' => 'iq',
            'netherlands' => 'nl',
            'latvia' => 'lv',
            'austria' => 'at',
            'belarus' => 'by',
            'thailand' => 'th',
            'saudiarabia' => 'sa',
            'mexico' => 'mx',
            'taiwan' => 'tw',
            'spain' => 'es',
            'iran' => 'ir',
            'algeria' => 'dz',
            'slovenia' => 'si',
            'bangladesh' => 'bd',
            'senegal' => 'sn',
            'turkey' => 'tr',
            'czechrepublic' => 'cz',
            'srilanka' => 'lk',
            'peru' => 'pe',
            'pakistan' => 'pk',
            'newzealand' => 'nz',
            'guinea' => 'gn',
            'mali' => 'ml',
            'venezuela' => 've',
            'ethiopia' => 'et',
            'mongolia' => 'mn',
            'brazil' => 'br',
            'afghanistan' => 'af',
            'uganda' => 'ug',
            'angola' => 'ao',
            'cyprus' => 'cy',
            'france' => 'fr',
            'papua' => 'pg',
            'mozambique' => 'mz',
            'nepal' => 'np',
            'belgium' => 'be',
            'bulgaria' => 'bg',
            'hungary' => 'hu',
            'moldova' => 'md',
            'italy' => 'it',
            'paraguay' => 'py',
            'honduras' => 'hn',
            'tunisia' => 'tn',
            'nicaragua' => 'ni',
            'timorleste' => 'tl',
            'bolivia' => 'bo',
            'costarica' => 'cr',
            'guatemala' => 'gt',
            'uae' => 'ae',
            'zimbabwe' => 'zw',
            'puertorico' => 'pr',
            'sudan' => 'sd',
            'togo' => 'tg',
            'kuwait' => 'kw',
            'elsalvador' => 'sv',
            'libyan' => 'ly',
            'jamaica' => 'jm',
            'trinidad' => 'tt',
            'ecuador' => 'ec',
            'swaziland' => 'sz',
            'oman' => 'om',
            'bosniaand' => 'ba',
            'dominicanrepublic' => 'do',
            'syria' => 'sy',
            'antigua' => 'ag',
            'armenia' => 'am',
            'seychelles' => 'sc',
            'newcaledonia' => 'nc',
            'solomon' => 'sb',
            'panama' => 'pa',
            'mauritius' => 'mu',
            'singapore' => 'sg',
            'jordan' => 'jo',
            'luxembourg' => 'lu',
            'grenada' => 'gd',
            'barbados' => 'bb',
            'fiji' => 'fj',
            'burundi' => 'bi',
            'japan' => 'jp',
            'maldives' => 'mv',
            'guyana' => 'gy',
            'georgia' => 'ge',
            'bahamas' => 'bs',
            'albania' => 'al',
            'uruguay' => 'uy',
            'mauritania' => 'mr',
            'bhutan' => 'bt',
            'macao' => 'mo',
            'lesotho' => 'ls',
            'sierra' => 'sl',
            'benin' => 'bj',
            'liberia' => 'lr',
            'rwanda' => 'rw',
            'suriname' => 'sr',
            'zambia' => 'zm',
            'malawi' => 'mw',
            'djibouti' => 'dj',
            'belize' => 'bz',
            'fiji' => 'fj',
            'guineabissau' => 'gw',
            'portugal' => 'pt',
            'switzerland' => 'ch',
            'greece' => 'gr',
            'chile' => 'cl',
            'denmark' => 'dk',
            'finland' => 'fi',
            'norway' => 'no',
            'australia' => 'au',
            'guinea-bissau' => 'gw',
        ];

        $normalizedName = strtolower(str_replace([' ', '-'], '', $countryName));
        return $countryMap[$normalizedName] ?? 'un';
    }

    private function process5sim($purchase)
    {
        $token = env('FIVESIM_TOKEN');

        if (!$token) {
            $this->refundUserBalance($purchase['cost']);
            Log::error('FIVESIM_TOKEN not configured');
            return back()->withErrors('Service configuration error. Balance refunded.');
        }

        try {
            Log::info('5sim purchase attempt', [
                'user_id' => auth()->id(),
                'service' => $purchase['service'],
                'country' => $purchase['country'],
                'operator' => $purchase['operator']
            ]);

            // Make purchase request to 5sim
            $response = Http::timeout(30)
                ->withHeaders([
                    'Authorization' => "Bearer {$token}",
                    'Accept' => 'application/json'
                ])
                ->get("https://5sim.net/v1/user/buy/activation/{$purchase['country']}/{$purchase['operator']}/{$purchase['service']}");

            Log::info('5sim API response', [
                'status' => $response->status(),
                'body' => $response->body()
            ]);

            if ($response->failed()) {
                $this->refundUserBalance($purchase['cost']);
                
                Log::error('5sim purchase failed', [
                    'status' => $response->status(),
                    'body' => $response->body()
                ]);
                
                $errorMsg = 'Failed to purchase number. ';
                $responseData = $response->json();
                if (isset($responseData['message'])) {
                    $errorMsg .= $responseData['message'];
                }
                
                return back()->withErrors($errorMsg . ' Your balance has been refunded.');
            }

            $data = $response->json();

            // Validate response data
            if (!isset($data['id']) || !isset($data['phone'])) {
                $this->refundUserBalance($purchase['cost']);
                Log::error('5sim invalid response structure', ['data' => $data]);
                return back()->withErrors('Invalid response from service. Your balance has been refunded.');
            }

            // Create transaction record
            $transactionId = DB::table('transactions')->insertGetId([
                'reference' => 'ACT_' . strtoupper(Str::random(10)),
                'request_id' => (string)$data['id'],
                'user_id' => auth()->id(),
                'type' => 'activation',
                'channel' => '5sim',
                'provider' => $purchase['service_name'],
                'service_id' => $purchase['service'],
                'service_name' => $purchase['service_name'],
                'service_logo' => null, // 5sim doesn't provide logos
                'country_id' => null, // 5sim uses country names, not IDs
                'country_name' => $purchase['country_name'],
                'country_code' => $this->getCountryCodeFrom5simCountry($purchase['country']),
                'operator_name' => $purchase['operator_name'] ?? null,
                'phone' => $data['phone'] ?? null,
                'sms_code' => null,
                'amount' => $purchase['cost'],
                'original_cost_usd' => $purchase['original_cost_usd'] ?? null,
                'status' => 'pending',
                'expires_at' => now()->addMinutes(20),
                'response' => json_encode($data),
                'description' => "5sim activation for {$purchase['service_name']} - {$purchase['country_name']}",
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            Log::info('Successful 5sim purchase', [
                'user_id' => auth()->id(),
                'transaction_id' => $transactionId,
                'order_id' => $data['id'],
                'phone' => $data['phone']
            ]);

            session()->forget('purchase');

            // Redirect to history page with activation ID
            return redirect()->route('history')->with('new_activation', $transactionId);

        } catch (\Exception $e) {
            $this->refundUserBalance($purchase['cost']);
            Log::error('5sim purchase exception', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return back()->withErrors('An error occurred. Your balance has been refunded.');
        }
    }

    private function fetchSms5sim($activation)
    {
        $token = env('FIVESIM_TOKEN');

        if (!$token) {
            return response()->json([
                'success' => false,
                'message' => 'Service token not configured'
            ], 500);
        }

        try {
            $response = Http::timeout(15)
                ->withHeaders([
                    'Authorization' => "Bearer {$token}",
                    'Accept' => 'application/json'
                ])
                ->get("https://5sim.net/v1/user/check/{$activation->request_id}");

            if ($response->failed()) {
                Log::error('5sim check failed', [
                    'status' => $response->status(),
                    'body' => $response->body()
                ]);
                
                return response()->json([
                    'success' => false,
                    'status' => 'pending',
                    'message' => 'Service temporarily unavailable'
                ]);
            }

            $data = $response->json();

            Log::info('5sim SMS check', [
                'request_id' => $activation->request_id,
                'status' => $data['status'] ?? 'unknown',
                'has_sms' => isset($data['sms']) && !empty($data['sms'])
            ]);

            // Check if SMS received
            if (isset($data['sms']) && !empty($data['sms'])) {
                // SMS can be array or single object
                $smsData = is_array($data['sms']) ? $data['sms'][0] : $data['sms'];
                $smsText = is_array($smsData) ? ($smsData['text'] ?? $smsData['code'] ?? '') : $smsData;
                
                // Extract code from SMS text
                $code = $this->extractCode($smsText);

                if ($code) {
                    DB::table('transactions')
                        ->where('id', $activation->id)
                        ->update([
                            'sms_code' => $code,
                            'status' => 'completed',
                            'updated_at' => now()
                        ]);

                    // Finish the activation on 5sim
                    try {
                        Http::timeout(10)
                            ->withHeaders([
                                'Authorization' => "Bearer {$token}",
                                'Accept' => 'application/json'
                            ])
                            ->get("https://5sim.net/v1/user/finish/{$activation->request_id}");
                    } catch (\Exception $e) {
                        Log::warning('Failed to finish 5sim activation', ['error' => $e->getMessage()]);
                    }

                    return response()->json([
                        'success' => true,
                        'sms_code' => $code,
                        'status' => 'completed'
                    ]);
                }
            }

            // Check activation status
            $status = $data['status'] ?? 'PENDING';
            
            if ($status === 'FINISHED') {
                DB::table('transactions')
                    ->where('id', $activation->id)
                    ->update([
                        'status' => 'completed',
                        'updated_at' => now()
                    ]);

                return response()->json([
                    'success' => false,
                    'status' => 'completed',
                    'message' => 'Activation finished'
                ]);
            } elseif ($status === 'CANCELED' || $status === 'TIMEOUT') {
                DB::table('transactions')
                    ->where('id', $activation->id)
                    ->update([
                        'status' => 'expired',
                        'updated_at' => now()
                    ]);

                return response()->json([
                    'success' => false,
                    'status' => 'expired',
                    'message' => 'Activation expired'
                ]);
            }

            // Still waiting
            return response()->json([
                'success' => false,
                'status' => 'pending',
                'message' => 'Waiting for SMS'
            ]);

        } catch (\Exception $e) {
            Log::error('5sim SMS fetch error', [
                'error' => $e->getMessage(),
                'request_id' => $activation->request_id
            ]);

            return response()->json([
                'success' => false,
                'message' => 'Error fetching SMS',
                'status' => 'pending'
            ], 500);
        }
    }

    private function cancel5sim($activation)
    {
        $token = env('FIVESIM_TOKEN');

        if (!$token) {
            return [
                'success' => false,
                'message' => 'Service token not configured'
            ];
        }

        try {
            $response = Http::timeout(15)
                ->withHeaders([
                    'Authorization' => "Bearer {$token}",
                    'Accept' => 'application/json'
                ])
                ->get("https://5sim.net/v1/user/cancel/{$activation->request_id}");

            if ($response->successful()) {
                Log::info('5sim activation cancelled', [
                    'request_id' => $activation->request_id
                ]);
                
                return ['success' => true];
            }

            $data = $response->json();
            Log::error('5sim cancel failed', [
                'status' => $response->status(),
                'response' => $data
            ]);

            return [
                'success' => false,
                'message' => $data['message'] ?? 'Failed to cancel activation'
            ];

        } catch (\Exception $e) {
            Log::error('5sim cancel error', [
                'error' => $e->getMessage(),
                'request_id' => $activation->request_id
            ]);

            return [
                'success' => false,
                'message' => 'Error cancelling request'
            ];
        }
    }

    // ==================== SMS-BUS METHODS (UNCHANGED) ====================

    public function showCountries($serviceId)
    {
        $token = env('SMSBUS_TOKEN');
        
        if (!$token) {
            Log::error('SMSBUS_TOKEN not configured');
            $emptyPaginator = new LengthAwarePaginator([], 0, 20, 1);
            return view('users.countries', [
                'countries' => $emptyPaginator,
                'serviceId' => $serviceId
            ])->withErrors('Service configuration error. Please contact support.');
        }

        $cacheKey = "smsbus_countries_prices_{$serviceId}";
        
        try {
            // Fetch countries with prices from the API
            $countries = Cache::remember($cacheKey, 300, function () use ($token, $serviceId) {
                Log::info('Fetching SMS-Bus countries with prices', ['serviceId' => $serviceId]);
                
                $response = Http::timeout(30)
                    ->get("https://sms-bus.com/api/resource/list/prices", [
                        'projectId' => $serviceId,
                        'token' => $token
                    ]);

                Log::info('SMS-Bus countries API response', [
                    'status' => $response->status(),
                    'successful' => $response->successful()
                ]);

                if (!$response->successful()) {
                    Log::error('Failed to fetch SMS-Bus countries', [
                        'status' => $response->status(),
                        'body' => $response->body()
                    ]);
                    return collect([]);
                }

                $responseData = $response->json();
                
                // Debug: Log the response structure
                Log::info('SMS-Bus API response structure', [
                    'has_data' => isset($responseData['data']),
                    'data_type' => isset($responseData['data']) ? gettype($responseData['data']) : 'null',
                    'data_count' => isset($responseData['data']) ? count($responseData['data']) : 0,
                    'first_item_sample' => isset($responseData['data'][0]) ? $responseData['data'][0] : null,
                    'response_keys' => array_keys($responseData)
                ]);
                
                if (!isset($responseData['data']) || empty($responseData['data'])) {
                    Log::warning('No countries data in SMS-Bus response', [
                        'full_response' => $responseData
                    ]);
                    return collect([]);
                }

                // Transform the data
                $countries = collect($responseData['data'])->map(function ($item) {
                    // Handle both associative arrays and objects
                    $countryId = $item['country_id'] ?? ($item['id'] ?? null);
                    $title = $item['title'] ?? ($item['country_name'] ?? ($item['name'] ?? 'Unknown'));
                    $code = $item['code'] ?? ($item['country_code'] ?? 'xx');
                    
                    return [
                        'country_id' => $countryId,
                        'title' => $title,
                        'code' => isset($code) ? strtolower($code) : 'xx',
                        'project_id' => $item['project_id'] ?? null,
                        'project_code' => $item['project_code'] ?? '',
                        'cost' => $item['cost'] ?? ($item['price'] ?? 0),
                        'ws_cost' => $item['ws_cost'] ?? ($item['cost'] ?? ($item['price'] ?? 0)),
                        'total_count' => $item['total_count'] ?? ($item['count'] ?? ($item['qty'] ?? 0)),
                        'sort' => $item['sort'] ?? ($item['order'] ?? 999),
                        'flag_url' => isset($code) && $code !== 'xx'
                            ? "https://flagcdn.com/w80/" . strtolower($code) . ".png"
                            : "https://ui-avatars.com/api/?name=" . urlencode(substr($title, 0, 2)) . "&background=cccccc&color=ffffff&size=80"
                    ];
                })->filter(function ($item) {
                    // Filter out items with invalid essential data
                    return !empty($item['country_id']) && !empty($item['title']) && $item['title'] !== 'Unknown';
                });

                // Sort by sort order, then by total count
                $countries = $countries->sortBy([
                    ['sort', 'asc'],
                    ['total_count', 'desc']
                ])->values();

                Log::info('SMS-Bus countries processed', [
                    'total_count' => $countries->count(),
                    'first_country' => $countries->first(),
                    'has_valid_data' => $countries->isNotEmpty()
                ]);

                return $countries;
            });

            // Handle search
            $search = request()->get('search', '');
            if ($search) {
                $countries = $countries->filter(function($country) use ($search) {
                    return str_contains(strtolower($country['title']), strtolower($search)) ||
                        str_contains(strtolower($country['code']), strtolower($search));
                })->values();
            }

            // Check if countries is empty after filtering
            if ($countries->isEmpty()) {
                Log::warning('No countries available after filtering', [
                    'service_id' => $serviceId,
                    'search' => $search,
                    'cache_had_data' => Cache::has($cacheKey)
                ]);
            }

            $perPage = 20;
            $page = request()->get('page', 1);
            $total = $countries->count();

            // Create paginator for both AJAX and regular requests
            $paginatedCountries = new LengthAwarePaginator(
                $countries->forPage($page, $perPage)->values(),
                $total,
                $perPage,
                $page,
                ['path' => request()->url(), 'query' => request()->query()]
            );

            // Handle AJAX requests for infinite scroll
            if (request()->ajax()) {
                return response()->json([
                    'success' => true,
                    'data' => $paginatedCountries->items(),
                    'current_page' => $paginatedCountries->currentPage(),
                    'last_page' => $paginatedCountries->lastPage(),
                    'total' => $paginatedCountries->total(),
                    'per_page' => $paginatedCountries->perPage(),
                    'has_more_pages' => $paginatedCountries->hasMorePages()
                ]);
            }

            // For initial page load
            return view('users.countries', [
                'countries' => $paginatedCountries,
                'serviceId' => $serviceId
            ]);

        } catch (\Exception $e) {
            Log::error('SMS-Bus countries exception', [
                'serviceId' => $serviceId,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            $emptyPaginator = new LengthAwarePaginator([], 0, 20, 1);

            if (request()->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'An error occurred loading countries: ' . $e->getMessage(),
                    'data' => [],
                    'current_page' => 1,
                    'last_page' => 1,
                    'total' => 0
                ], 500);
            }

            return view('users.countries', [
                'countries' => $emptyPaginator,
                'serviceId' => $serviceId
            ])->withErrors('An error occurred loading countries: ' . $e->getMessage());
        }
    }

    public function getPrices(Request $request, $serviceId, $countryId)
    {
        $token = env('SMSBUS_TOKEN');

        $response = Http::get("https://sms-bus.com/api/control/list/prices", [
            'token'      => $token,
            'country_id' => $countryId,
        ]);

        if ($response->failed()) {
            return response()->json([
                'status' => false,
                'message' => 'Failed to fetch prices',
            ], 500);
        }

        $data = $response->json();

        if (!isset($data['data'])) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid response from API',
            ], 500);
        }

        $prices = collect($data['data'])
            ->filter(function ($item) use ($serviceId) {
                return (int) $item['project_id'] === (int) $serviceId;
            })
            ->map(function ($item) {
                return [
                    'project_id' => $item['project_id'],
                    'name'       => ucfirst($item['project_code']),
                    'cost'       => $item['cost'],
                    'count'      => $item['total_count'],
                    'country_id' => $item['country_id'],
                    'country_name' => $item['country_name'] ?? 'Unknown',
                    'country_code' => $item['country_code'] ?? '',
                ];
            })
            ->values()
            ->toArray();

        return response()->json([
            'status' => true,
            'data'   => $prices,
        ]);
    }

    /**
 * ✅ Get service details by ID
 */
private function getServiceDetails($serviceIdentifier, $isCode = false): array
    {
        try {
            if ($isCode) {
                // For 5sim - search by code
                $cacheKey = "smsbus_service_by_code_{$serviceIdentifier}";
                $serviceData = Cache::remember($cacheKey, 300, function () use ($serviceIdentifier) {
                    $token = env('SMSBUS_TOKEN');
                    $response = Http::timeout(20)->get("https://sms-bus.com/api/control/list/projects", [
                        'token' => $token
                    ]);

                    if ($response->successful()) {
                        $data = $response->json('data');
                        if (is_array($data)) {
                            foreach ($data as $service) {
                                if (strtolower($service['code']) === strtolower($serviceIdentifier)) {
                                    return [
                                        'name' => $service['title'],
                                        'code' => $service['code'],
                                        'id' => $service['id']
                                    ];
                                }
                            }
                        }
                    }
                    return null;
                });

                if ($serviceData) {
                    return [
                        'name' => $serviceData['name'],
                        'logo' => null,
                        'code' => $serviceData['code']
                    ];
                }

                // Fallback to formatted code
                return [
                    'name' => ucfirst($serviceIdentifier),
                    'logo' => null,
                    'code' => $serviceIdentifier
                ];
            } else {
                // For SMS-Bus - search by ID
                $cacheKey = "smsbus_service_{$serviceIdentifier}";
                $serviceData = Cache::remember($cacheKey, 300, function () use ($serviceIdentifier) {
                    $token = env('SMSBUS_TOKEN');
                    $response = Http::timeout(20)->get("https://sms-bus.com/api/control/list/projects", [
                        'token' => $token
                    ]);

                    if ($response->successful()) {
                        $data = $response->json('data');
                        if (is_array($data)) {
                            foreach ($data as $service) {
                                if ($service['id'] == $serviceIdentifier) {
                                    return [
                                        'name' => $service['title'],
                                        'code' => $service['code'],
                                        'id' => $service['id']
                                    ];
                                }
                            }
                        }
                    }
                    return null;
                });

                if ($serviceData) {
                    return [
                        'name' => $serviceData['name'],
                        'logo' => null,
                        'code' => $serviceData['code']
                    ];
                }
            }
        } catch (\Exception $e) {
            Log::error('Error fetching service details', [
                'identifier' => $serviceIdentifier,
                'error' => $e->getMessage()
            ]);
        }

        // ✅ Fallback
        return [
            'name' => 'Unknown Service',
            'logo' => null,
            'code' => 'unknown'
        ];
    }

    /**
     * ✅ IMPROVED: Get country name from API or cache
     */
    private function getCountryDetails($countryIdentifier, $isName = false): array
    {
        try {
            if ($isName) {
                // For 5sim - already have the country name
                $countryCode = $this->getCountryCode($countryIdentifier);
                return [
                    'name' => ucfirst($countryIdentifier),
                    'code' => $countryCode
                ];
            } else {
                // For SMS-Bus - fetch from API by country_id
                $token = env('SMSBUS_TOKEN');
                $cacheKey = "smsbus_country_{$countryIdentifier}";
                
                $countryData = Cache::remember($cacheKey, 300, function () use ($token, $countryIdentifier) {
                    $response = Http::timeout(20)->get("https://sms-bus.com/api/control/list/prices", [
                        'token' => $token,
                        'country_id' => $countryIdentifier
                    ]);

                    if ($response->successful()) {
                        $data = $response->json('data');
                        if (is_array($data) && !empty($data)) {
                            $first = $data[0];
                            return [
                                'name' => $first['country_name'] ?? 'Unknown',
                                'code' => strtolower($first['country_code'] ?? 'xx')
                            ];
                        }
                    }
                    return null;
                });

                if ($countryData) {
                    return $countryData;
                }
            }
        } catch (\Exception $e) {
            Log::error('Error fetching country details', [
                'identifier' => $countryIdentifier,
                'error' => $e->getMessage()
            ]);
        }

        return [
            'name' => 'Unknown Country',
            'code' => 'xx'
        ];
    }

    public function preparePurchase(Request $request)
    {
        $request->validate([
            'service' => 'required|integer',
            'country' => 'required|integer',
        ]);

        $serviceId = $request->service;
        $countryId = $request->country;
        $token = env('SMSBUS_TOKEN');

        if (!$token) {
            Log::error('SMSBUS_TOKEN not configured');
            return back()->withErrors('Service configuration error');
        }

        $cacheKey = "price_data_{$serviceId}_{$countryId}";
        $priceData = Cache::remember($cacheKey, 300, function () use ($token, $countryId, $serviceId) {
            try {
                $response = Http::timeout(30)->get("https://sms-bus.com/api/control/list/prices", [
                    'token' => $token,
                    'country_id' => $countryId,
                ]);

                if ($response->failed() || !isset($response->json()['data'])) {
                    return null;
                }

                $responseData = $response->json();
                return collect($responseData['data'])
                    ->where('country_id', $countryId)
                    ->where('project_id', $serviceId)
                    ->first();
            } catch (\Exception $e) {
                Log::error('Error fetching price data', ['error' => $e->getMessage()]);
                return null;
            }
        });

        if (!$priceData || !isset($priceData['cost']) || $priceData['cost'] <= 0) {
            return back()->withErrors('No pricing available for this service.');
        }

        // ✅ Get the exchange rate
        $exchangeRate = $this->getExchangeRate();

        // ✅ Get service details
        $serviceDetails = $this->getServiceDetails($serviceId, false);
        
        // ✅ Get country details from price data
        $countryDetails = [
            'name' => $priceData['country_name'] ?? 'Unknown',
            'code' => strtolower($priceData['country_code'] ?? 'xx')
        ];

        $purchase = [
            'provider'        => self::PROVIDER_SMSBUS,
            'country_id'      => $countryId,
            'country_name'    => $countryDetails['name'],
            'country_code'    => $countryDetails['code'],
            'service'         => $priceData['project_id'],
            'service_name'    => $serviceDetails['name'],
            'service_logo'    => $serviceDetails['logo'] ?? null,
            'cost'            => round($priceData['cost'] * $exchangeRate, 2),
            'original_cost_usd' => $priceData['cost'],
            'exchange_rate'   => $exchangeRate,
            'total_count'     => $priceData['total_count'] ?? 0,
            'timestamp'       => time(),
            'session_token'   => bin2hex(random_bytes(16)),
        ];

        if ($purchase['cost'] <= 0) {
            return back()->withErrors('Invalid service pricing. Please contact support.');
        }

        session(['purchase' => encrypt($purchase)]);

        Log::info('SMS-Bus purchase session created', [
            'user_id' => auth()->id(),
            'service' => $serviceId,
            'service_name' => $serviceDetails['name'],
            'country' => $countryId,
            'country_name' => $countryDetails['name'],
            'exchange_rate' => $exchangeRate,
            'usd_cost' => $priceData['cost'],
            'ngn_cost' => $purchase['cost']
        ]);

        return redirect()->route('confirm.payment');
    }


    private function processSmsbus($purchase)
{
    $token = env('SMSBUS_TOKEN');

    if (!$token) {
        $this->refundUserBalance($purchase['cost']);
        Log::error('SMSBUS_TOKEN not configured');
        return back()->withErrors('Service configuration error. Balance refunded.');
    }

    try {
        Log::info('SMS-Bus purchase attempt', [
            'user_id' => auth()->id(),
            'project_id' => $purchase['service'],
            'country_id' => $purchase['country_id'],
            'cost' => $purchase['cost']
        ]);

        $response = Http::timeout(30)
            ->withOptions(['verify' => false])
            ->get("https://sms-bus.com/api/control/get/number", [
                'project_id' => $purchase['service'],
                'country_id' => $purchase['country_id'],
                'token' => $token,
                'reuse' => false
            ]);

        Log::info('SMS-Bus API response', [
            'status' => $response->status(),
            'body' => $response->body()
        ]);

        if ($response->failed()) {
            $this->refundUserBalance($purchase['cost']);
            
            Log::error('SMS-Bus purchase failed', [
                'response_status' => $response->status(),
                'response_body' => $response->body()
            ]);
            
            return back()->withErrors('Failed to purchase number. Your balance has been refunded.');
        }

        $data = $response->json();

        // Check for successful response
        if (!isset($data['code']) || $data['code'] !== 200) {
            $this->refundUserBalance($purchase['cost']);
            
            $errorMessage = $data['message'] ?? 'Failed to purchase number';
            
            Log::error('SMS-Bus purchase unsuccessful', [
                'error' => $errorMessage,
                'data' => $data
            ]);
            
            return back()->withErrors($errorMessage . '. Your balance has been refunded.');
        }

        // Verify we have the required data
        if (!isset($data['data']['request_id']) || !isset($data['data']['number'])) {
            $this->refundUserBalance($purchase['cost']);
            
            Log::error('SMS-Bus invalid response structure', ['data' => $data]);
            
            return back()->withErrors('Invalid response from service. Your balance has been refunded.');
        }

        // Create activation transaction record
        $activationTransaction = DB::table('activation_transactions')->insertGetId([
            'user_id' => auth()->id(),
            'request_id' => $data['data']['request_id'],
            'phone_number' => $data['data']['number'],
            'service_id' => $purchase['service'],
            'service_name' => $purchase['service_name'],
            'service_logo' => $purchase['service_logo'] ?? null,
            'country_id' => $purchase['country_id'],
            'country_name' => $purchase['country_name'],
            'country_code' => $purchase['country_code'],
            'cost' => $purchase['cost'],
            'original_cost_usd' => $purchase['original_cost_usd'] ?? null,
            'status' => 'pending',
            'provider' => 'smsbus',
            'sms_code' => null,
            'expires_at' => now()->addMinutes(20),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Create transaction record
        DB::table('transactions')->insert([
            'reference' => 'ACT_' . strtoupper(Str::random(10)),
            'user_id' => auth()->id(),
            'type' => 'activation',
            'channel' => 'SMS-Bus',
            'provider' => $purchase['service_name'],
            'phone' => $data['data']['number'],
            'amount' => $purchase['cost'],
            'status' => 'success',
            'response' => json_encode($data),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Log::info('Successful SMS-Bus purchase', [
            'user_id' => auth()->id(),
            'activation_id' => $activationTransaction,
            'request_id' => $data['data']['request_id'],
            'phone' => $data['data']['number']
        ]);

        session()->forget('purchase');

        // Redirect to history page with activation ID
        return redirect()->route('history')->with('new_activation', $activationTransaction);

    } catch (\Exception $e) {
        $this->refundUserBalance($purchase['cost']);
        
        Log::error('SMS-Bus purchase exception', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        
        return back()->withErrors('An error occurred. Your balance has been refunded.');
    }
}

    // ==================== COMMON METHODS ====================

   public function showConfirm()
    {
        try {
            $encryptedPurchase = session('purchase');
            
            if (!$encryptedPurchase) {
                Log::warning('No purchase session found', ['user_id' => auth()->id()]);
                return redirect()->route('services.list')->withErrors('No purchase session found. Please start the process again.');
            }

            $purchase = decrypt($encryptedPurchase);

            $requiredFields = ['service', 'cost', 'timestamp', 'provider'];
            foreach ($requiredFields as $field) {
                if (!isset($purchase[$field])) {
                    Log::error('Invalid purchase session - missing field', ['missing_field' => $field]);
                    session()->forget('purchase');
                    return redirect()->route('services.list')->withErrors('Invalid purchase session. Please start again.');
                }
            }

            if ((time() - $purchase['timestamp']) > 1800) {
                Log::info('Purchase session expired', ['user_id' => auth()->id()]);
                session()->forget('purchase');
                return redirect()->route('services.list')->withErrors('Purchase session expired. Please start the process again.');
            }

            $wallet = auth()->user()->wallet;

            if (!$wallet) {
                Log::warning('User wallet not found', ['user_id' => auth()->id()]);
                return redirect()->route('services.list')->withErrors('No wallet found. Please contact support.');
            }

            if ($wallet->balance < $purchase['cost']) {
                return view('users.numberProcess', compact('purchase', 'wallet'))
                    ->withErrors('Insufficient wallet balance. Please top up your account.');
            }

            Log::info('Purchase confirmation page loaded', [
                'user_id' => auth()->id(),
                'service_name' => $purchase['service_name'] ?? 'Unknown',
                'country_name' => $purchase['country_name'] ?? 'Unknown',
                'cost' => $purchase['cost'],
                'exchange_rate' => $purchase['exchange_rate'] ?? 'N/A'
            ]);

            return view('users.numberProcess', compact('purchase', 'wallet'));

        } catch (\Exception $e) {
            Log::error('Error in showConfirm', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            session()->forget('purchase');
            return redirect()->route('services.list')->withErrors('An error occurred. Please try again.');
        }
    }
}